import { Color, DirectionalLight, HemisphereLight, PerspectiveCamera, PointLight, type Scene, Vector3 } from 'three';
import { createLightingRig } from '@app/utils/lighting/lightingRig';
import type { DisposalScope } from '@app/utils/disposal';

/** Configuration for a mini-game camera. */
export interface GameCameraOptions {
  /** Camera name prefix (e.g. 'fireflies'). */
  name: string;
  /** Vertical angle in radians. Default 1.2. */
  beta?: number;
  /** Distance from target. Default 9.0. */
  radius?: number;
  /** Look-at target. Default (0, 0.5, 0). */
  target?: Vector3;
  /** Field of view in radians. Default 0.85. */
  fov?: number;
}

/**
 * Creates a locked PerspectiveCamera suitable for mini-games.
 * The camera is positioned using spherical coordinates derived from the
 * original ArcRotateCamera parameters (alpha=0, beta, radius) and looks at
 * the target point. No orbit controls are attached.
 *
 * @param opts - Camera configuration.
 * @param aspect - Viewport aspect ratio. Defaults to 16/9.
 * @returns A configured PerspectiveCamera.
 */
export function createGameCamera(opts: GameCameraOptions, aspect = 16 / 9): PerspectiveCamera {
  const beta = opts.beta ?? 1.2;
  const radius = opts.radius ?? 9.0;
  const target = opts.target ?? new Vector3(0, 0.5, 0);
  const fov = opts.fov ?? 0.85;

  // Babylon fov is vertical in radians; Three.js PerspectiveCamera expects degrees.
  const fovDeg = (fov * 180) / Math.PI;

  const camera = new PerspectiveCamera(fovDeg, aspect, 0.1, 100);
  camera.name = `${opts.name}_camera`;

  // Convert Babylon ArcRotateCamera spherical coords (alpha=0, beta, radius) to cartesian.
  // Babylon uses a left-handed system; Three.js is right-handed. Negate Z to compensate.
  const alpha = 0;
  const x = radius * Math.sin(beta) * Math.sin(alpha);
  const y = radius * Math.cos(beta);
  const z = -(radius * Math.sin(beta) * Math.cos(alpha));

  camera.position.set(target.x + x, target.y + y, target.z + z);
  camera.lookAt(target);

  return camera;
}

/** Configuration for the standard three-light mini-game rig. */
export interface GameLightingOptions {
  /** Light name prefix (e.g. 'fireflies'). */
  name: string;
  /** Directional light direction (will be normalized). Default (-1, -3, 2). */
  direction?: Vector3;
  /** Directional light intensity. Default 0.7. */
  directionalIntensity?: number;
  /** Ambient fill intensity. Default 0.5. */
  hemisphericIntensity?: number;
  /** Point light position. Default (0, 4, -1). */
  pointPosition?: Vector3;
  /** Point light intensity. Default 0.3. */
  pointIntensity?: number;
}

/** The three lights returned by createGameLighting (fill is a hemisphere — flat when sky===ground). */
export interface GameLightingRig {
  directionalLight: DirectionalLight;
  ambientLight: HemisphereLight;
  pointLight: PointLight;
}

/**
 * Creates the standard mini-game lighting by mapping the game vocabulary onto
 * the unified {@link createLightingRig} (see architecture-standards.md#lightingrig).
 * A thin adapter — the rig adds the lights to the scene and scope-owns them, so
 * the caller no longer adds or disposes them. The game's flat ambient fill is a
 * hemisphere with `sky === ground`.
 *
 * @param scene - The scene to add the lights to.
 * @param opts - Lighting configuration.
 * @param scope - Disposal scope that frees the lights (and shadow map) on teardown.
 * @returns The three light instances (already added to the scene).
 */
export function createGameLighting(scene: Scene, opts: GameLightingOptions, scope: DisposalScope): GameLightingRig {
  const white = new Color(0xffffff);
  const rig = createLightingRig(
    scene,
    {
      key: { direction: opts.direction ?? new Vector3(-1, -3, 2), intensity: opts.directionalIntensity ?? 0.7, color: white },
      fill: { skyColor: white, groundColor: white, intensity: opts.hemisphericIntensity ?? 0.5 },
      accents: [{ position: opts.pointPosition ?? new Vector3(0, 4, -1), intensity: opts.pointIntensity ?? 0.3, color: white }],
      // Preserve the mini-games' tighter shadow frustum/near for crisper local shadows.
      shadow: { near: 0.5, frustum: 5 },
    },
    scope,
  );
  return { directionalLight: rig.key, ambientLight: rig.fill, pointLight: rig.accents[0] };
}

/**
 * Disposes camera and all three lights from a game rig.
 *
 * @param camera - The game camera (may be null).
 * @param lights - The lighting rig (may be null).
 */
export function disposeGameRig(camera: PerspectiveCamera | null, lights: GameLightingRig | null): void {
  if (lights) {
    lights.pointLight.removeFromParent();
    lights.ambientLight.removeFromParent();
    lights.directionalLight.removeFromParent();
  }
  if (camera) camera.removeFromParent();
}

// ── Backward-compat type aliases used by game setup modules ──────────────────
/** @deprecated Use PerspectiveCamera instead. */
export type GameCamera = PerspectiveCamera;
/** @deprecated Use GameLightingRig instead. */
export type GameLights = GameLightingRig;
