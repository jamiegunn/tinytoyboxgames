import { Scene, Color, Vector3, type Mesh, type MeshStandardMaterial, type Object3D } from 'three';
import { buildShark as buildSharkMesh, buildFish as buildFishMesh } from '@app/minigames/shared/animalBuilder';
import { getParticleEngine } from '@app/utils/particles/registry';
import { PARTICLES, GLOW_TRAIL_RATE } from '@app/utils/particles/presets';
import type { StreamHandle } from '@app/utils/particles/engine';
import { disposeMeshDeep } from '@app/minigames/shared/disposal';
import type { FishState, FishKind } from '../types';
import { FISH_COLORS, GOLDEN_COLOR, GOLDEN_SCALE, FISH_BASE_SPEED_MIN, FISH_BASE_SPEED_MAX, MIN_SPAWN_DISTANCE } from '../types';
import { randomRange, randomPositionAwayFrom } from '../helpers';

/**
 * Fish entity lifecycle — creation, disposal, and shark construction.
 */

/** Counter for unique mesh naming. */
let meshIndex = 0;

/** Component handles returned by {@link buildSharkEntity}. */
export interface SharkComponents {
  sharkRoot: Mesh;
  sharkBody: Object3D | null;
  sharkGlowTrail: StreamHandle;
  /** Tail fin meshes (for wag animation). */
  tailFins: Object3D[];
  /** Eye white meshes (for blink animation). */
  eyes: Object3D[];
}

// Reef-shark palette for the animalBuilder shark.
//
// `buildShark` (minigames/shared/animalBuilder.ts) is shared with other games,
// so its colours cannot move; it builds the shark from linear (0.42, 0.56,
// 0.72) with a (0.96, 0.96, 0.97) belly. Under this scene's rig that body
// albedo has a luminance of 0.542 against reef sand at 0.691 — 20 sRGB levels
// apart before the fog lerp touches either of them, and the fog then multiplies
// the residual by 0.73. Measured on the shipped build, the shark rendered at
// rgb(119, 147, 168) against water at rgb(117, 142, 151): a delta of 5
// luminance levels. The shark was, literally, the same value as the sea.
//
// Slate (0.14, 0.23, 0.33) is the dark dorsal surface every real reef shark
// has, and it is a value the reef cannot produce: the frame model puts the
// shark at display luminance 72 against 136 for the sand behind it, a delta of
// 63. Counter-shading is the point — a dark back over a pale belly is exactly
// how a shark reads as a shark from above.
const SHARK_BODY_COLOR = new Color(0.14, 0.23, 0.33);

// The fins and the second body segment, one step darker so the silhouette has
// internal structure instead of reading as one flat cut-out.
const SHARK_DARK_COLOR = new Color(0.09, 0.15, 0.22);

// The counter-shaded underside. Held just below white so it has somewhere to go
// when the shark rolls into the key light.
const SHARK_BELLY_COLOR = new Color(0.86, 0.88, 0.9);

// Repaints the shared animalBuilder shark into this scene's palette.
//
// Keyed on the MATERIAL name, not the mesh name. `buildShark` allocates exactly
// three skin materials and shares each across several meshes — `_skinMat` covers
// the body, mid-body, peduncle, both pectorals and the ventral fin — so keying
// on mesh names would have had the mid-body's assignment overwrite the body's on
// the same material object. The eyes, iris, pupil, teeth, mouth and cheek blush
// have their own materials and are left exactly as built.
//
// The materials are per-shark (each `skinMat` call allocates), so writing to
// them here cannot leak into any other game that calls `buildShark`.
//
// Emissive is re-derived from the new albedo because animalBuilder sets it as a
// fraction of the colour it was built with; leaving it would have kept a
// blue-grey glow sitting on top of a slate body.
function recolourShark(root: Object3D): void {
  root.traverse((child) => {
    const mat = (child as Mesh).material as MeshStandardMaterial | undefined;
    if (!mat || !mat.color || typeof mat.name !== 'string') return;
    if (mat.name.endsWith('_darkSkinMat')) {
      mat.color.copy(SHARK_DARK_COLOR);
    } else if (mat.name.endsWith('_skinMat')) {
      mat.color.copy(SHARK_BODY_COLOR);
    } else if (mat.name.endsWith('_whiteSkin')) {
      mat.color.copy(SHARK_BELLY_COLOR);
    } else {
      return;
    }
    if (mat.emissive) mat.emissive.copy(mat.color).multiplyScalar(0.04);
  });
}

/**
 * Builds the player shark entity with glow trail and explicit component handles.
 * @param scene - The Three.js scene.
 * @param sharkPos - Initial shark world position.
 * @returns Shark root mesh, body child mesh, glow trail, and component arrays.
 */
export function buildSharkEntity(scene: Scene, sharkPos: Vector3): SharkComponents {
  const sharkGroup = buildSharkMesh(`shark_${meshIndex++}`, sharkPos.clone());
  scene.add(sharkGroup);
  const sharkRoot = sharkGroup as unknown as Mesh;

  let sharkBody: Object3D | null = null;
  const tailFins: Object3D[] = [];
  const eyes: Object3D[] = [];
  sharkRoot.traverse((child) => {
    if (child.name.includes('_body')) sharkBody = child;
    if (child.name.includes('tailFin')) tailFins.push(child);
    if (child.name.includes('eyeWhite')) eyes.push(child);
  });
  recolourShark(sharkRoot);

  const sharkGlowTrail = getParticleEngine(scene).stream(PARTICLES.glowTrail, sharkRoot, GLOW_TRAIL_RATE, {
    colors: [new Color(0.3, 0.6, 1.0)],
  });

  return { sharkRoot, sharkBody, sharkGlowTrail, tailFins, eyes };
}

/**
 * Creates a fish entity using the shared animalBuilder.
 * @param scene - The Three.js scene.
 * @param sharkPos - Current shark position (used to spawn away from).
 * @param kind - The fish kind to create.
 * @returns A fresh FishState.
 */
export function createFish(scene: Scene, sharkPos: Vector3, kind: FishKind): FishState {
  const prefix = kind === 'golden' ? 'golden' : 'fish';
  const color = kind === 'golden' ? GOLDEN_COLOR : FISH_COLORS[Math.floor(Math.random() * FISH_COLORS.length)];

  const [spawnX, spawnZ] = randomPositionAwayFrom(sharkPos.x, sharkPos.z, MIN_SPAWN_DISTANCE);
  const fishGroup = buildFishMesh(`${prefix}_${meshIndex++}`, new Vector3(spawnX, 0, spawnZ), color);
  scene.add(fishGroup);
  const root = fishGroup as unknown as Mesh;

  // Standard fish are much smaller than the shark
  if (kind === 'standard') {
    root.scale.setScalar(0.55);
  }

  if (kind === 'golden') {
    root.scale.setScalar(GOLDEN_SCALE * 0.6);
    let bodyChild: Object3D | null = null;
    root.traverse((child) => {
      if (child.name.includes('_body')) bodyChild = child;
    });
    if (bodyChild && (bodyChild as Mesh).material && 'emissive' in ((bodyChild as Mesh).material as object)) {
      ((bodyChild as Mesh).material as MeshStandardMaterial).emissive = new Color(0.4, 0.35, 0.05);
    }
  }

  let bodyPickMesh: Object3D | null = null;
  root.traverse((child) => {
    if (child.name.includes('_body')) bodyPickMesh = child;
  });

  return {
    root,
    bodyPickMesh: bodyPickMesh ?? root,
    kind,
    active: true,
    driftPhaseX: Math.random() * Math.PI * 2,
    driftPhaseZ: Math.random() * Math.PI * 2,
    driftSpeed: randomRange(FISH_BASE_SPEED_MIN, FISH_BASE_SPEED_MAX),
    driftCenterX: spawnX,
    driftCenterZ: spawnZ,
    despawnTimer: -1,
    dodgeCount: 0,
    dodgeCooldown: 0,
    isTargeted: false,
    spawning: false,
    spawnTimer: 0,
    spawnEdgeX: 0,
    spawnEdgeZ: 0,
  };
}

/**
 * Resets a pooled fish for reuse.
 * @param fish - The fish state to reset.
 * @param sharkPos - Current shark position.
 */
export function resetFishForSpawn(fish: FishState, sharkPos: Vector3): void {
  const [spawnX, spawnZ] = randomPositionAwayFrom(sharkPos.x, sharkPos.z, MIN_SPAWN_DISTANCE);
  fish.root.position.set(spawnX, 0, spawnZ);
  fish.root.scale.setScalar(0.55);
  fish.root.visible = true;

  // Randomize color
  const color = FISH_COLORS[Math.floor(Math.random() * FISH_COLORS.length)];
  fish.root.traverse((child) => {
    if (child.name.includes('_body') && (child as Mesh).material && 'color' in ((child as Mesh).material as object)) {
      ((child as Mesh).material as MeshStandardMaterial).color = color;
    }
  });

  fish.active = true;
  fish.driftPhaseX = Math.random() * Math.PI * 2;
  fish.driftPhaseZ = Math.random() * Math.PI * 2;
  fish.driftSpeed = randomRange(FISH_BASE_SPEED_MIN, FISH_BASE_SPEED_MAX);
  fish.driftCenterX = spawnX;
  fish.driftCenterZ = spawnZ;
  fish.despawnTimer = -1;
  fish.dodgeCount = 0;
  fish.dodgeCooldown = 0;
  fish.isTargeted = false;
  fish.spawning = false;
  fish.spawnTimer = 0;
  fish.spawnEdgeX = 0;
  fish.spawnEdgeZ = 0;
}

/**
 * Hides a fish and marks it inactive for pooling.
 * @param fish - The fish to deactivate.
 */
export function deactivateFish(fish: FishState): void {
  fish.active = false;
  fish.root.visible = false;
}

/**
 * Disposes a fish entity permanently.
 * @param fish - The fish to dispose.
 */
export function disposeFish(fish: FishState): void {
  disposeMeshDeep(fish.root);
}

/**
 * Resets the mesh index counter.
 */
export function resetMeshIndex(): void {
  meshIndex = 0;
}
