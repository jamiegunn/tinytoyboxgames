import { Color, type Object3D, type Mesh } from 'three';

// ── Fish color variants ──────────────────────────────────────────────

/**
 * Color palette for standard fish variants.
 *
 * A fish has to be pickable out of the water at a glance by a three-year-old,
 * which means value contrast, not just hue. Measuring each albedo through the
 * actual pipeline — Lambert shading at the rig in environment/setup.ts, then
 * ACES filmic at exposure 1.15 — against the water colour there (relative
 * luminance 0.204 on screen):
 *
 *   orange     (1.00, 0.55, 0.15)  ->  0.32   1.57 : 1
 *   yellow     (1.00, 0.90, 0.25)  ->  0.47   2.30 : 1
 *   turquoise  (0.75, 1.00, 0.95)  ->  0.45   2.19 : 1
 *   green      (0.35, 0.95, 0.40)  ->  0.38   1.85 : 1
 *   pink       (1.00, 0.60, 0.80)  ->  0.36   1.74 : 1
 *
 * The old blue (0.3, 0.5, 1.0) measured 0.274 -> 1.28 : 1 — the same hue AND
 * very nearly the same lightness as the water behind it, so a blue fish was
 * effectively camouflaged. Replaced with a pale turquoise that keeps the cool
 * slot in the palette while sitting well above the background in value. The
 * other four were nudged brighter to widen the spread; every one now clears
 * 1.5 : 1, and all five differ from each other in luminance as well as hue so
 * they stay distinguishable rather than reading as one shoal of pastel.
 */
export const FISH_COLORS: Color[] = [
  new Color(1.0, 0.55, 0.15), // orange
  new Color(1.0, 0.9, 0.25), // yellow
  new Color(0.75, 1.0, 0.95), // turquoise
  new Color(0.35, 0.95, 0.4), // green
  new Color(1.0, 0.6, 0.8), // pink
];

/** Golden fish body color. */
export const GOLDEN_COLOR = new Color(1.0, 0.85, 0.2);

// ── Bounds ───────────────────────────────────────────────────────────

/** Play area extent on each axis (±BOUNDS). */
export const BOUNDS = 50.0;

// ── Fish hit radius ─────────────────────────────────────────────────

/** Generous hit radius for standard fish — easy to catch. */
export const FISH_HIT_RADIUS = 1.0;

/** Generous hit radius for golden fish — easy to catch. */
export const GOLDEN_HIT_RADIUS = 1.5;

// ── Fish speed (MIN/MAX bounds, interpolated by difficulty) ─────────

export const FISH_BASE_SPEED_MIN = 1.0;
export const FISH_BASE_SPEED_MAX = 1.8;

// ── Fish count (MIN/MAX bounds, interpolated by difficulty) ─────────
//
// Defect 3: nothing read these — the spawner hard-coded 2 nearby fish forever.
// They are now the on-screen fish budget the spawner maintains, ramping with
// `difficulty.level` (manifest ramp {start: 4, end: 40}, so 4 catches to leave
// the floor and 40 to reach the ceiling).
//
// MIN was 3. Measured with the headless tap probe (24 taps in a 6x4 grid over a
// 1200x810 canvas — the same sweep the live harness runs): a floor of 3 left a
// mean of 2.96 fish actually inside the camera frustum, and the nearest fish to
// a given tap sat a mean of 338 px away, further than any believable aim assist
// could reach. At 5 the frustum holds 6.0 and the nearest fish is 220 px away,
// and the grid sweep goes from 5.9 catches to 11.0. Three fish spread over a
// 15-unit radius is not an easy difficulty setting for a three-year-old, it is
// an empty reef.

export const MIN_FISH_COUNT = 5;
export const MAX_FISH_COUNT = 8;

// ── Speed multiplier (MIN/MAX bounds, interpolated by difficulty) ───
//
// Defect 3: the old 1.0→1.4 band was then multiplied by 0.5 at the call site,
// so fish crawled at 0.5–0.7x and the ramp was imperceptible. The 0.5 is gone
// and the band is widened: a beginner's fish is slightly slower than before,
// and a veteran's is roughly twice as quick.

export const MIN_SPEED_MULTIPLIER = 0.55;
export const MAX_SPEED_MULTIPLIER = 1.45;

// ── Evasiveness (MIN/MAX bounds, interpolated by difficulty) ────────
//
// Defect 3: fish evasion was fixed — a 1.5-unit startle radius and exactly two
// golden dodges, no matter how good the child got. Normalized 0–1; see
// `getFishEvasiveness` and its consumers in fish/effects.ts.

export const MIN_EVASIVENESS = 0.0;
export const MAX_EVASIVENESS = 1.0;

// ── Golden fish ─────────────────────────────────────────────────────

export const GOLDEN_SPAWN_INTERVAL = 12.0;
export const GOLDEN_SCALE = 1.4;

// ── Golden fish dodge ───────────────────────────────────────────────

/** Distance the golden fish darts sideways during a dodge. */
export const GOLDEN_DODGE_DISTANCE = 1.5;
/** Duration of a single dodge animation in seconds. */
export const GOLDEN_DODGE_DURATION = 0.3;
/** Cooldown between consecutive dodges in seconds. */
export const GOLDEN_DODGE_COOLDOWN = 2.0;
/** Maximum number of dodges before the golden fish becomes "tired." */
export const GOLDEN_MAX_DODGES = 2;
/** Speed multiplier applied to tired golden fish (after max dodges). */
export const GOLDEN_TIRED_SPEED_MULTIPLIER = 0.5;

// ── Scoring ─────────────────────────────────────────────────────────

/** Points awarded per fish kind. */
export const FISH_POINTS: Record<'standard' | 'golden', number> = {
  standard: 1,
  golden: 5,
};

/** Milestone schedule — contextual celebrations at specific scores. */
export const MILESTONE_SCHEDULE: { score: number; size: 'small' | 'medium' | 'large' }[] = [
  { score: 3, size: 'small' },
  { score: 8, size: 'medium' },
  { score: 15, size: 'large' },
];

/** After the last scheduled milestone, repeat every N points. */
export const MILESTONE_REPEAT_INTERVAL = 10;

// ── Spawning ────────────────────────────────────────────────────────

/** Minimum distance from shark when placing a new fish. */
export const MIN_SPAWN_DISTANCE = 4.0;

// ── Animation timing ────────────────────────────────────────────────

export const EAT_ANIM_DURATION = 0.6;
export const FISH_DESPAWN_SCALE_DURATION = 0.2;
/** The body scaling.x value used by animalBuilder for the shark body. */
export const SHARK_BODY_SCALE_X = 1.15;

// ── Environment ─────────────────────────────────────────────────────

export const CAUSTIC_LIGHT_COUNT = 4;

// ── Camera ──────────────────────────────────────────────────────────

export const CAMERA_RADIUS_PORTRAIT = 13.0;
export const CAMERA_RADIUS_LANDSCAPE = 10.0;

// ── Fish state ──────────────────────────────────────────────────────

/** Discriminated fish kind — determines scoring, appearance, and dodge behavior. */
export type FishKind = 'standard' | 'golden';

/** Internal state for a single fish entity. */
export interface FishState {
  root: Mesh;
  /** The body child mesh used for tap-picking. */
  bodyPickMesh: Object3D;
  /** Discriminated kind — use this for behavior branching. */
  kind: FishKind;
  active: boolean;
  driftPhaseX: number;
  driftPhaseZ: number;
  driftSpeed: number;
  driftCenterX: number;
  driftCenterZ: number;
  /** Countdown for despawn scale-to-zero animation, -1 when not despawning. */
  despawnTimer: number;
  /** Number of dodges performed (golden fish only). */
  dodgeCount: number;
  /** Cooldown timer until next dodge is possible. */
  dodgeCooldown: number;
  /** Whether this fish is the current target of a player tap-lunge. */
  isTargeted: boolean;
  /** Whether this fish is in spawn-arrival animation (not yet catchable). */
  spawning: boolean;
  /** Timer for spawn arrival animation. */
  spawnTimer: number;
  /** Edge position this fish spawned from (for arrival animation). */
  spawnEdgeX: number;
  /** Edge position this fish spawned from (for arrival animation). */
  spawnEdgeZ: number;
}
