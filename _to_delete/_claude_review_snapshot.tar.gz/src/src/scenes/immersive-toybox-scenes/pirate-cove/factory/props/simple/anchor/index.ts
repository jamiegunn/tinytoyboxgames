export { composeAnchor } from './compose';
