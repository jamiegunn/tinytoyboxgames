export { composeTreasureChests } from './compose';
