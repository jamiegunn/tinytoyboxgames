/**
 * Hub background music module for the Whimsical Toybox World.
 * Procedurally generates a gentle music-box lullaby via Web Audio synthesis — no audio files.
 *
 * Arrangement (three layers):
 * - Music-box melody: sine fundamental + inharmonic ~4.2x partial (the metallic
 *   "comb tooth" ping real music boxes have) + soft octave shimmer, in the C5
 *   register where music boxes actually live.
 * - Chord pad: detuned triangle voices through a lowpass, slow attack/release,
 *   following a I-vi-IV-V progression with common-tone voicings.
 * - Bass: one soft sine an octave below each chord root.
 *
 * The melody is a 4-phrase AABA tune that cadences properly (B4 leading tone
 * resolving to C5 over G -> C), scheduled sample-accurately via the shared
 * lookahead loop scheduler. Every other cycle drops the pad for variety.
 */

import { midiToFreq } from '@app/assets/audio/utils/synthHelpers';
import { startAudioLoop } from '@app/assets/audio/utils/loopScheduler';

/** Base duration of one melody step in seconds. */
const STEP_S = 0.4;

/** Melody peak gain (soft background level; bus gain does the rest). */
const MELODY_GAIN = 0.13;

/** Pad per-voice gain. */
const PAD_GAIN = 0.045;

/** Bass note gain. */
const BASS_GAIN = 0.06;

/** Inharmonic music-box partial ratio (real music boxes ring near 4.2x). */
const PARTIAL_RATIO = 4.2;

/**
 * One melodic phrase: MIDI notes plus per-note duration multipliers.
 * The final note of each phrase is held for two steps to let it breathe.
 */
interface Phrase {
  notes: number[];
  beats: number[];
}

// MIDI reference: C5 = 72.
const PHRASE_A: Phrase = {
  notes: [72, 76, 79, 81, 79, 76, 74, 72],
  beats: [1, 1, 1, 1, 1, 1, 1, 2],
};

const PHRASE_B: Phrase = {
  notes: [76, 79, 81, 84, 81, 79, 76, 74],
  beats: [1, 1, 1, 1, 1, 1, 1, 2],
};

/** Closing phrase: walks down to the leading tone and resolves home. */
const PHRASE_A_CADENCE: Phrase = {
  notes: [72, 76, 79, 81, 79, 74, 71, 72],
  beats: [1, 1, 1, 1, 1, 1, 1, 2],
};

/** AABA form. */
const PHRASES: Phrase[] = [PHRASE_A, PHRASE_A, PHRASE_B, PHRASE_A_CADENCE];

/** Chord voicings (MIDI) — two chords per phrase, half a phrase each. */
const PHRASE_CHORDS: Array<[number[], number[]]> = [
  [
    [60, 64, 67], // C
    [57, 60, 64], // Am
  ],
  [
    [53, 57, 60], // F
    [55, 59, 62], // G
  ],
  [
    [57, 60, 64], // Am
    [53, 57, 60], // F
  ],
  [
    [55, 59, 62], // G
    [60, 64, 67], // C — resolution under the melodic cadence
  ],
];

/**
 * Seconds in one phrase (sum of beats * step).
 *
 * @param phrase - The phrase whose duration to compute.
 * @returns Phrase duration in seconds.
 */
function phraseSeconds(phrase: Phrase): number {
  return phrase.beats.reduce((sum, b) => sum + b, 0) * STEP_S;
}

/** Total cycle length in seconds. */
const CYCLE_S = PHRASES.reduce((sum, p) => sum + phraseSeconds(p), 0);

/**
 * Schedules a single music-box note: sine fundamental, inharmonic partial,
 * and a soft octave shimmer, with slight velocity humanization.
 *
 * @param ctx - The Web Audio context.
 * @param destination - The destination AudioNode.
 * @param frequency - Note frequency in Hz.
 * @param startTime - Audio-clock time to start the note.
 * @param durationS - Nominal note duration in seconds.
 */
function scheduleMusicBoxNote(ctx: AudioContext, destination: AudioNode, frequency: number, startTime: number, durationS: number): void {
  const velocity = MELODY_GAIN * (0.85 + Math.random() * 0.3);
  const ringS = Math.max(durationS * 1.4, 0.5);

  // Fundamental — pure music-box tone
  const osc1 = ctx.createOscillator();
  osc1.type = 'sine';
  osc1.frequency.value = frequency;
  const gain1 = ctx.createGain();
  gain1.gain.setValueAtTime(0, startTime);
  gain1.gain.linearRampToValueAtTime(velocity, startTime + 0.008);
  gain1.gain.exponentialRampToValueAtTime(0.001, startTime + ringS);
  osc1.connect(gain1).connect(destination);
  osc1.start(startTime);
  osc1.stop(startTime + ringS + 0.05);

  // Inharmonic partial — fast-decaying metallic ping
  const osc2 = ctx.createOscillator();
  osc2.type = 'sine';
  osc2.frequency.value = frequency * PARTIAL_RATIO;
  const gain2 = ctx.createGain();
  gain2.gain.setValueAtTime(0, startTime);
  gain2.gain.linearRampToValueAtTime(velocity * 0.22, startTime + 0.005);
  gain2.gain.exponentialRampToValueAtTime(0.001, startTime + 0.16);
  osc2.connect(gain2).connect(destination);
  osc2.start(startTime);
  osc2.stop(startTime + 0.25);

  // Octave shimmer — quiet, rounds out the tone
  const osc3 = ctx.createOscillator();
  osc3.type = 'triangle';
  osc3.frequency.value = frequency * 2;
  const gain3 = ctx.createGain();
  gain3.gain.setValueAtTime(0, startTime);
  gain3.gain.linearRampToValueAtTime(velocity * 0.18, startTime + 0.01);
  gain3.gain.exponentialRampToValueAtTime(0.001, startTime + ringS * 0.7);
  osc3.connect(gain3).connect(destination);
  osc3.start(startTime);
  osc3.stop(startTime + ringS + 0.05);
}

/**
 * Schedules one soft pad chord: detuned triangle voices through a lowpass.
 *
 * @param ctx - The Web Audio context.
 * @param destination - The destination AudioNode.
 * @param chordMidi - MIDI notes of the chord voicing.
 * @param startTime - Audio-clock time the chord begins.
 * @param durationS - Chord duration in seconds.
 */
function schedulePadChord(ctx: AudioContext, destination: AudioNode, chordMidi: number[], startTime: number, durationS: number): void {
  const lowpass = ctx.createBiquadFilter();
  lowpass.type = 'lowpass';
  lowpass.frequency.value = 850;
  lowpass.connect(destination);

  const attackS = Math.min(1.1, durationS * 0.4);
  const releaseS = Math.min(1.4, durationS * 0.5);
  const endTime = startTime + durationS + releaseS;

  for (const midi of chordMidi) {
    for (const detune of [-4, 4]) {
      const osc = ctx.createOscillator();
      osc.type = 'triangle';
      osc.frequency.value = midiToFreq(midi);
      osc.detune.value = detune;

      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0, startTime);
      gain.gain.linearRampToValueAtTime(PAD_GAIN, startTime + attackS);
      gain.gain.setValueAtTime(PAD_GAIN, startTime + durationS - 0.05);
      gain.gain.linearRampToValueAtTime(0, endTime);

      osc.connect(gain).connect(lowpass);
      osc.start(startTime);
      osc.stop(endTime + 0.05);
    }
  }
}

/**
 * Schedules one soft bass note an octave below the chord root.
 *
 * @param ctx - The Web Audio context.
 * @param destination - The destination AudioNode.
 * @param rootMidi - MIDI note of the chord root.
 * @param startTime - Audio-clock time the note begins.
 * @param durationS - Note duration in seconds.
 */
function scheduleBassNote(ctx: AudioContext, destination: AudioNode, rootMidi: number, startTime: number, durationS: number): void {
  const osc = ctx.createOscillator();
  osc.type = 'sine';
  osc.frequency.value = midiToFreq(rootMidi - 12);

  const gain = ctx.createGain();
  gain.gain.setValueAtTime(0, startTime);
  gain.gain.linearRampToValueAtTime(BASS_GAIN, startTime + 0.08);
  gain.gain.setValueAtTime(BASS_GAIN, startTime + durationS * 0.7);
  gain.gain.linearRampToValueAtTime(0, startTime + durationS);

  osc.connect(gain).connect(destination);
  osc.start(startTime);
  osc.stop(startTime + durationS + 0.05);
}

/**
 * Schedules one full AABA cycle: melody, pads, and bass.
 *
 * @param ctx - The Web Audio context.
 * @param destination - The destination AudioNode.
 * @param baseTime - Audio-clock time at which the cycle begins.
 * @param withPad - Whether to include the pad/bass layers this cycle.
 */
function scheduleCycle(ctx: AudioContext, destination: AudioNode, baseTime: number, withPad: boolean): void {
  let phraseStart = baseTime;

  for (let p = 0; p < PHRASES.length; p++) {
    const phrase = PHRASES[p];
    const phraseDur = phraseSeconds(phrase);

    // Harmony: two chords per phrase, each covering half the phrase.
    if (withPad) {
      const [chordA, chordB] = PHRASE_CHORDS[p];
      schedulePadChord(ctx, destination, chordA, phraseStart, phraseDur / 2);
      schedulePadChord(ctx, destination, chordB, phraseStart + phraseDur / 2, phraseDur / 2);
      scheduleBassNote(ctx, destination, chordA[0], phraseStart, phraseDur / 2);
      scheduleBassNote(ctx, destination, chordB[0], phraseStart + phraseDur / 2, phraseDur / 2);
    }

    // Melody on top
    let offset = 0;
    for (let i = 0; i < phrase.notes.length; i++) {
      const noteDur = phrase.beats[i] * STEP_S;
      scheduleMusicBoxNote(ctx, destination, midiToFreq(phrase.notes[i]), phraseStart + offset, noteDur);
      offset += noteDur;
    }

    phraseStart += phraseDur;
  }
}

/**
 * Plays the looping music-box lullaby for the Playroom Hub.
 * Sample-accurate looping via the shared lookahead scheduler; the pad and
 * bass layers rest every other cycle so the piece breathes over time.
 *
 * @param ctx - The Web Audio context
 * @param destination - The destination AudioNode to connect output to
 * @returns A cleanup function that stops the loop
 */
export function playMusHubBackground(ctx: AudioContext, destination: AudioNode): () => void {
  let cycleIndex = 0;
  return startAudioLoop(ctx, CYCLE_S, (startTime) => {
    const withPad = cycleIndex % 2 === 0;
    scheduleCycle(ctx, destination, startTime, withPad);
    cycleIndex++;
  });
}
