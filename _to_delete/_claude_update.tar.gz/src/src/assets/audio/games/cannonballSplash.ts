/**
 * Cannonball Splash minigame sounds. The game fires `sfx_cannonball_fire` on
 * every shot; it was previously unregistered, so the flagship interaction was
 * silent. This is a friendly toy cannon: a soft low thump with a "poomp"
 * sweep — no harsh transients for small ears.
 */

import { playTone, playFreqSweep, playFilteredNoiseBurst, rand } from '@app/assets/audio/utils/synthHelpers';

/** Minimum fade-in time in seconds to avoid clicks. */
const MIN_ATTACK_S = 0.005;

/**
 * Plays a soft toy-cannon fire: low sine thump, downward "poomp" sweep, and a
 * gentle air-puff of filtered noise.
 *
 * @param ctx - The Web Audio context
 * @param dest - The destination AudioNode to connect output to
 */
export function playSfxCannonballFire(ctx: AudioContext, dest: AudioNode): void {
  const now = ctx.currentTime;

  // Low body thump
  playTone(ctx, dest, 'sine', 90 + rand(-10, 10), 0.01, 0.16, 0.2, now);

  // "Poomp" sweep
  playFreqSweep(ctx, dest, 'sine', 380 + rand(-40, 40), 140, MIN_ATTACK_S, 0.18, 0.12, now);

  // Air puff
  playFilteredNoiseBurst(ctx, dest, 600, 1, MIN_ATTACK_S, 0.12, 0.07, now);
}
