# Code Review: Standardization, Snowflakes, and Code Smells

Date: 2026-07-19

Scope: Review of the Tiny Toybox Games codebase with emphasis on lack of standardization, special-case implementations, code smells, hacks, and architectural drift. These findings are not automatically bad; some may be warranted. The goal is to identify where exceptions exist and judge whether they look intentional, contained, and worth keeping.

## Executive Summary

The repo has unusually good guardrails: strict TypeScript, zero-warning precommit checks, generated templates, central scene cataloging, framework contract tests, and explicit migration comments around camera, particle, disposal, lighting, and math standards.

The main concern is not general messiness. The main concern is that several older transitional abstractions still coexist with newer standards. That creates a risk that legacy compatibility paths become a second unofficial standard.

Highest-priority issues:

1. Raw `requestAnimationFrame` loops still bypass the documented `FrameClock` standard.
2. Two disposal systems coexist, and the older one violates the newer disposal contract.
3. The referenced architecture standard document appears missing from the repo.
4. Route/hash handling has an asymmetry between the app shell and scene router.
5. The mini-game manifest exposes mutable runtime registration even though the repo otherwise favors canonical generated registries.

## Findings

### 1. High: Self-Owned `requestAnimationFrame` Loops Bypass the FrameClock Standard

Evidence:

- `src/utils/frameClock.ts` documents `FrameClock` as the single per-frame pump per rendering surface.
- It explicitly says effects should subscribe to the scene's single `FrameClock` instead of starting their own `requestAnimationFrame` loops.
- `src/minigames/games/little-shark/effects/particles.ts` still contains a self-updating rAF loop for a burst particle effect.
- `src/scenes/immersive-toybox-scenes/naturescene/factory/props/complex/stream/water-surface/index.ts` still contains a private rAF loop for shader time.

Why it matters:

The project already identifies this exact pattern as something `FrameClock` was meant to remove: self-driven loops can outlive teardown, drift from the render loop, and waste battery. The stream loop at least returns `killAnimation`, but it is still a special lifecycle path. The little-shark burst loop has no cancellation handle at all; if teardown happens while particles are alive, the loop can keep touching removed or disposed objects until natural expiry.

Judgment:

This is a real standards drift, not just a harmless implementation detail. These should be migrated to `FrameClock.subscribe(...)` and bound to the owning `DisposalScope`.

Suggested fix:

- Replace the little-shark burst loop with a `clock.subscribe` callback or move the effect onto the shared particle engine.
- Replace stream shader time updates with a `FrameClock` subscription registered in the scene's disposal scope.
- Consider adding a test or lint rule that blocks new raw `requestAnimationFrame` usage outside approved renderer hosts such as `SceneFrame` and `MiniGameShell`.

### 2. High: Two Disposal Standards Coexist

Evidence:

- `src/utils/disposal.ts` states that `DisposalScope` replaces scattered disposal helpers, including `createDisposeCollector`.
- `DisposalScope` guarantees LIFO disposal, idempotence, and exception isolation.
- `src/utils/sceneHelpers.ts` still exports `createDisposeCollector`.
- `createDisposeCollector` disposes FIFO, is not exception-isolated, and does not protect remaining cleanups if one cleanup throws.
- The immersive scene template and Nature scene still use this older collector pattern.

Why it matters:

Generated or copied immersive scene code can continue to reproduce the older lifecycle model. This weakens the value of the newer `DisposalScope` standard because new code has two plausible cleanup APIs with different semantics.

Judgment:

This is probably transitional debt. It may have been warranted during migration, but it should now be either removed, wrapped, or very clearly quarantined as legacy-only.

Suggested fix:

- Update immersive scene templates to use `DisposalScope`.
- Replace `createDisposeCollector` call sites with a child disposal scope.
- If compatibility is needed, rewrite `createDisposeCollector` internally to delegate to `DisposalScope` so its semantics match the standard.
- Add a test ensuring generated immersive scenes use `DisposalScope` rather than the older collector.

### 3. Medium: Referenced Architecture Standard Document Appears Missing

Evidence:

- Many files reference `architecture-standards.md`, including runtime modules and framework tests.
- A workspace search did not find an `architecture-standards.md` file.
- Only scattered comments and tests currently encode the human-readable standard.

Why it matters:

The codebase clearly has real architectural rules, but the canonical human-readable source of truth appears absent. New contributors or another LLM agent would have to infer the rules from comments, tests, and implementation details. That is brittle, especially in a generated-code-heavy repo.

Judgment:

This is a documentation/standardization gap. The standard exists culturally and structurally, but it is not available where the code says it is.

Suggested fix:

- Add or restore `docs/ai-guidance/architecture-standards.md` or another canonical path.
- Include sections for `FrameClock`, `DisposalScope`, `ParticleEngine`, `CameraDescriptor`, `InteractionController`, `LightingRig`, and math helpers.
- Update references if the intended path is different.

### 4. Medium: SceneRouter Hash Handling Is Asymmetric

Evidence:

- `src/App.tsx` listens to both `hashchange` and `popstate` to resolve the top-level app view.
- `src/components/SceneRouter.tsx` only listens to `popstate` for internal scene/game state.
- `SceneRouter` also stores the normal navigation transition timeout in `transitionTimerRef`, but the popstate timeout is not stored or cleared.

Why it matters:

A direct valid hash change can keep the app in the 3D shell while the scene router state remains stale. The unstored timeout is also a small cleanup asymmetry. It is unlikely to be catastrophic, but it is the kind of special-case routing behavior that becomes hard to reason about as deep links and generated routes grow.

Judgment:

This looks like a real edge-case bug and a small standards smell around timer ownership.

Suggested fix:

- Have `SceneRouter` listen to `hashchange` as well as `popstate`, or centralize hash subscription behind one route store.
- Reuse the same transition timer helper for both direct navigation and browser/hash navigation.
- Ensure every transition timeout is stored and cleared on unmount.

### 5. Medium: Mini-Game Manifest Is Mutable at Runtime

Evidence:

- `src/minigames/framework/MiniGameManifest.ts` defines a central manifest array.
- The generator edits the manifest through a marker, which suggests this file is intended to be the canonical registration surface.
- `getManifest()` returns the underlying array as `ReadonlyArray`, but the same array remains mutable internally.
- `registerManifestEntry(entry)` exposes runtime mutation through `manifest.push(entry)`.
- No current usage of `registerManifestEntry` was found.

Why it matters:

Runtime mutation weakens the catalog discipline. It could allow duplicate ids, missing scene/game associations, or entries that bypass generator/test coverage. This contrasts with `SCENE_CATALOG`, which is more strongly treated as a canonical static registry.

Judgment:

This looks like an unused escape hatch. If runtime plugin registration is not a real product requirement, it should go.

Suggested fix:

- Remove `registerManifestEntry` if unused.
- Return a copied array from `getManifest()` if callers should not observe internal mutation.
- If runtime registration is truly needed, add validation for duplicate ids and scene association consistency.

### 6. Low: Helper Standardization Is Halfway Enforced

Evidence:

- `src/utils/math.ts` is the canonical math helper module.
- `src/minigames/shared/mathUtils.ts` and `src/utils/mathHelpers.ts` are compatibility re-exports.
- Several game-local helper modules still define or wrap generic helpers such as `lerp`, `clamp01`, and random range helpers.

Why it matters:

Some local helpers are domain-specific and fine. But generic math helpers are exactly the kind of small duplication that leads to subtle behavior differences, such as clamped vs unclamped interpolation. The repo already documents that this happened before.

Judgment:

Low severity, but worth tightening. The canonical direction is good; enforcement is incomplete.

Suggested fix:

- Keep compatibility modules if needed for older imports.
- For new code, require direct imports from `@app/utils/math`.
- Add a test or lint rule that flags newly introduced generic `lerp`, `clamp`, `randomRange`, or `randomInt` helpers outside the canonical module unless explicitly justified.

## Things That Look Strong

- The repo has strict TypeScript settings and a strong precommit quality gate.
- Scene registration is centralized through `SCENE_CATALOG`.
- Generated templates exist for room scenes, immersive scenes, and minigames.
- Several architecture standards are already represented in code and tests.
- The project has clearly been refactored toward shared abstractions: `FrameClock`, `DisposalScope`, `ParticleEngine`, `CameraDescriptor`, `LightingRig`, and centralized interaction dispatch.
- Comments often explain why a convention exists, not just what the code does.

## Priority Recommendations

1. Migrate raw rAF effect loops to `FrameClock` and bind them to `DisposalScope`.
2. Remove or wrap `createDisposeCollector` so all cleanup paths share `DisposalScope` semantics.
3. Add or restore the missing `architecture-standards.md` document.
4. Normalize hash navigation handling between `App` and `SceneRouter`.
5. Remove the unused runtime mini-game registration escape hatch unless it is a deliberate plugin API.
6. Add lightweight enforcement against new generic math helper duplication.

## Overall Judgment

This is not a sloppy codebase. It is a codebase with strong standards and some remaining transitional exceptions. The danger is that those exceptions are not all clearly quarantined. The best next step is not a broad rewrite; it is to close the remaining escape hatches so the architecture standards become mechanically hard to violate.
