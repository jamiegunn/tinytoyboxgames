export { composeSampleInteractiveProps } from './compose';
