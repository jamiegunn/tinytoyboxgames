export { composeSampleSimpleProps } from './compose';
