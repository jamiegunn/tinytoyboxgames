/**
 * That the letterbox is actually WIRED, not merely computed.
 *
 * WHY THIS EXISTS
 * ---------------
 * A mutation run found the hole. `src/utils/scene/stageRect.ts` has nine tests
 * of its own, every room framing is solved against the band it defines, and
 * every framing guard sweeps the aspects it produces — and with all of that
 * green, changing SceneFrame's canvas back to `width: '100%', height: '100%'`
 * broke nothing. The whole apparatus rests on one component applying one
 * rectangle, and nothing was checking that it did.
 *
 * HOW THIS IS DRIVEN
 * ------------------
 * `bundleComponent` swaps in a fake `react` whose JSX factory returns plain
 * `{ type, props, children }` objects, so a component can be CALLED and its
 * returned element tree inspected as data. Nothing is rendered and no DOM is
 * involved; what is asserted is the style the component asks for, which is the
 * only thing standing between the solved framings and the screen.
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import { bundleComponent } from '../framework/_tsload.mjs';

/** A phone: far narrower than the stage floor, so the letterbox has to bite. */
const PHONE = { width: 393, height: 852 };
/** A wide desktop: past the stage ceiling, so the pillarbox has to bite. */
const ULTRAWIDE = { width: 2560, height: 1080 };
/** A shape already inside the band, where the stage is the whole viewport. */
const INSIDE_BAND = { width: 1200, height: 1000 };

// The provider's context default calls `getResponsiveState()`, which reads
// `window`, and the module is evaluated at import time — so the globals have to
// exist before the bundle is loaded, not before the component is called.
let viewport = INSIDE_BAND;
globalThis.window = {
  get innerWidth() {
    return viewport.width;
  },
  get innerHeight() {
    return viewport.height;
  },
  addEventListener: () => {},
  removeEventListener: () => {},
  dispatchEvent: () => {},
};

const M = await bundleComponent(
  'stage-wiring',
  `
  export { SceneFrame } from './src/components/SceneFrame';
  export { UIOverlay } from './src/components/UIOverlay';
  export { resolveStageRect, resolveChromeBand, MIN_CHROME_BAND } from './src/utils/scene/stageRect';
  export { EFFECTS, __resetEffects, CONTEXTS } from 'react';
`,
);

// STAND THE CONTEXTS UP. `SceneRouterCtx` and `AudioCtx` are module-private and
// both default to null, so `useNavigation()` throws before the component reaches
// its first line of layout. Every null-defaulted context gets the same
// duck-typed stand-in rather than being matched up by creation order, which
// would silently re-pair itself the day a provider is added.
const STUB_CONTEXT = {
  currentScene: 'kitchen',
  activeMiniGame: null,
  isTransitioning: false,
  navigateTo: () => {},
  launchMiniGame: () => {},
  exitMiniGame: () => {},
  isMuted: false,
  toggleMute: () => {},
  playSound: () => {},
  startSceneAudio: () => {},
  stopSceneAudio: () => {},
  isAudioUnlocked: true,
};
for (const context of M.CONTEXTS) {
  if (context._v === null) context._v = STUB_CONTEXT;
}

// The one context that is NOT null-defaulted: the responsive state. Found by the
// shape of its default rather than by position, for the same reason.
const responsiveContext = M.CONTEXTS.find((c) => c._v && typeof c._v.viewportWidth === 'number');
if (!responsiveContext) throw new Error('no responsive context found — ResponsiveProvider no longer defaults to a viewport state');

/**
 * Calls a component at a given viewport and returns its element tree.
 *
 * @param component - The component function.
 * @param at - Viewport to report through the stubbed `window`.
 * @returns The returned element tree.
 */
function renderAt(component, at) {
  viewport = at;
  // The responsive context's default is computed ONCE, when the provider module
  // is evaluated — the stub has no re-render, so moving `window` afterwards
  // changes nothing on its own. Setting the context is what a resize does in the
  // real app, and it is the input under test here.
  responsiveContext._v = {
    viewportWidth: at.width,
    viewportHeight: at.height,
    orientation: at.width >= at.height ? 'landscape' : 'portrait',
    scaleFactor: Math.min(at.width / 1440, 1),
    isMobile: at.width < 768,
  };
  M.__resetEffects();
  return component({ children: null });
}

/**
 * Depth-first search of an element tree.
 *
 * @param node - Element, array, or primitive.
 * @param predicate - Match test.
 * @returns The first matching element, or null.
 */
function find(node, predicate) {
  if (!node || typeof node !== 'object') return null;
  if (Array.isArray(node)) {
    for (const child of node) {
      const hit = find(child, predicate);
      if (hit) return hit;
    }
    return null;
  }
  if (predicate(node)) return node;
  return find(node.children ?? [], predicate);
}

/**
 * Every element in a tree, flattened.
 *
 * @param node - Element, array, or primitive.
 * @returns All element objects, in document order.
 */
function all(node) {
  if (!node || typeof node !== 'object') return [];
  if (Array.isArray(node)) return node.flatMap(all);
  return [node, ...all(node.children ?? [])];
}

const canvasOf = (tree) => find(tree, (n) => n.type === 'canvas');

for (const [label, at] of [
  ['a phone', PHONE],
  ['an ultrawide desktop', ULTRAWIDE],
  ['a viewport inside the band', INSIDE_BAND],
]) {
  test(`SceneFrame sizes its canvas to the stage rect on ${label}`, () => {
    const canvas = canvasOf(renderAt(M.SceneFrame, at));
    assert.ok(canvas, 'SceneFrame no longer renders a canvas');
    const rect = M.resolveStageRect(at.width, at.height);
    assert.equal(canvas.props.style.width, rect.width, `${label}: canvas width is not the stage width`);
    assert.equal(canvas.props.style.height, rect.height, `${label}: canvas height is not the stage height`);
    assert.equal(canvas.props.style.left, rect.offsetX, `${label}: canvas is not at the stage offset`);
    assert.equal(canvas.props.style.top, rect.offsetY);
  });
}

test('the canvas is a measured box, not a percentage of the window', () => {
  // The exact regression a mutation reintroduced with nothing failing: a canvas
  // at 100% x 100% takes whatever aspect the device has, which is the state
  // every framing in this app was re-solved to escape.
  for (const at of [PHONE, ULTRAWIDE, INSIDE_BAND]) {
    const style = canvasOf(renderAt(M.SceneFrame, at)).props.style;
    for (const key of ['width', 'height']) {
      assert.equal(typeof style[key], 'number', `canvas ${key} is "${String(style[key])}" — a percentage tracks the window, not the stage`);
    }
  }
});

test('a phone really does lose height rather than width', () => {
  // Belt and braces on the direction of the letterbox. Squeezing the width
  // instead would also satisfy "the canvas is a measured box" while shrinking
  // the scene, which is the complaint the letterbox answers.
  const style = canvasOf(renderAt(M.SceneFrame, PHONE)).props.style;
  assert.equal(style.width, PHONE.width, 'the stage gave up width on a phone');
  assert.ok(style.height < PHONE.height, 'the stage kept the full height on a phone, so there is no chrome band');
});

test('UIOverlay puts its controls in the chrome band, not on top of the scene', () => {
  // The other half of letterboxing: if the buttons stay pinned to the viewport
  // corners they sit on the scene a child is meant to be able to touch, and the
  // band below it stays empty.
  const band = M.resolveChromeBand(PHONE.width, PHONE.height);
  assert.ok(band.below > 0, 'the fixture is wrong: this viewport has no band below the stage');
  const row = find(renderAt(M.UIOverlay, PHONE), (n) => n.props?.style?.height === band.below);
  assert.ok(row, `no element is laid out at the chrome band height ${band.below} — the HUD is still floating over the scene`);
  const stage = M.resolveStageRect(PHONE.width, PHONE.height);
  assert.equal(row.props.style.top, stage.height, 'the control row does not start where the stage ends');
});

test('every control is at least a finger wide, at every viewport', () => {
  // The old HUD was a fixed 48-56px however large or small the screen was. The
  // floor matters more than the ceiling here: platform guidance puts a touch
  // target around 44px for an adult, and this app is aimed at three-year-olds,
  // who aim worse.
  // The last two are the fixtures a mutation run demanded: dropping MIN_CONTROL
  // from 56 to 24 changed nothing until this swept viewports whose chrome band
  // is SMALL, because everywhere else the band-proportional size is far above
  // either floor and the floor is never the binding constraint.
  for (const at of [PHONE, ULTRAWIDE, INSIDE_BAND, { width: 320, height: 480 }, { width: 400, height: 420 }, { width: 1000, height: 700 }]) {
    for (const node of all(renderAt(M.UIOverlay, at))) {
      if (node.type !== 'button') continue;
      const { width, height } = node.props.style;
      assert.ok(width >= 44 && height >= 44, `a control is ${width}x${height} at ${at.width}x${at.height} — smaller than a fingertip`);
      assert.equal(width, height, 'a round control that is not round');
    }
  }
});

test('SceneFrame resizes the renderer when the stage box changes, not only on a window event', () => {
  // A window `resize` listener alone reads the canvas before React has laid it
  // out at the new size, so the renderer keeps the previous box for a frame and
  // the camera keeps the previous aspect. The effect that depends on the stage
  // dimensions is what closes that.
  renderAt(M.SceneFrame, PHONE);
  const stageEffects = M.EFFECTS.filter((e) => Array.isArray(e.deps) && e.deps.length === 2 && e.deps.every((d) => typeof d === 'number'));
  assert.equal(stageEffects.length, 1, 'expected exactly one effect keyed on the stage width and height');
  const rect = M.resolveStageRect(PHONE.width, PHONE.height);
  assert.deepEqual(stageEffects[0].deps, [rect.width, rect.height], 'the effect is keyed on something other than the stage box');
});

test('a band too thin to hold a control is not used as one', () => {
  // A viewport where the aspect invariant and the band floor cannot both be
  // satisfied. The region is narrow — the short axis has to be under about 266px
  // — but the branch is real, and laying the row out in a 73px band would put
  // 56px buttons hard against both its edges and over the scene.
  const SLIVER = { width: 250, height: 252 };
  const band = M.resolveChromeBand(SLIVER.width, SLIVER.height);
  assert.ok(band.below > 0 && band.below < M.MIN_CHROME_BAND, `the fixture is wrong: this viewport's band is ${band.below}, not a sliver`);
  const row = find(renderAt(M.UIOverlay, SLIVER), (n) => n.props?.style?.height === band.below);
  assert.equal(row, null, 'the HUD laid itself out inside a band too thin to hold it instead of floating');
});
